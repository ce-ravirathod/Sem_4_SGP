-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 06, 2024 at 05:28 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payroll_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

DROP TABLE IF EXISTS `attendence`;
CREATE TABLE IF NOT EXISTS `attendence` (
  `emp_id` varchar(10) NOT NULL,
  `date` varchar(255) NOT NULL,
  `punch_in` time NOT NULL,
  `punch_out` time NOT NULL,
  PRIMARY KEY (`emp_id`,`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`emp_id`, `date`, `punch_in`, `punch_out`) VALUES
('E0005', '03-17-24', '09:00:56', '20:59:13'),
('E0004', '03-17-24', '09:00:56', '19:59:13'),
('E0003', '03-17-24', '09:00:56', '18:59:12'),
('E0002', '03-17-24', '09:00:56', '17:59:13'),
('E0001', '03-17-24', '09:00:56', '16:59:13');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `emp_id` char(5) NOT NULL,
  `emp_password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `basicsalary` int(255) NOT NULL,
  `emp_type` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `address` longtext NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `joining_date` varchar(255) NOT NULL,
  `blood_group` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `account_no` varchar(255) NOT NULL,
  `ifsc_code` varchar(255) NOT NULL,
  `manager_id` char(5) NOT NULL,
  PRIMARY KEY (`emp_id`),
  KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `emp_password`, `first_name`, `last_name`, `dob`, `gender`, `basicsalary`, `emp_type`, `nationality`, `address`, `email`, `mobile`, `joining_date`, `blood_group`, `designation`, `bank_name`, `account_no`, `ifsc_code`, `manager_id`) VALUES
('E0001', 'password1', 'Rajesh', 'Patel', '1990-05-15', 'male', 40000, 'Admin', 'Indian', 'Ahmedabad, Gujarat', 'kumarrajesh@example.com', '1234567890', '2000-01-01', 'O+', 'Admin', ' Bank of India', '123456789', 'SBIN0123456', 'E0001'),
('E0002', '1234', 'Priya', 'Sharma', '1992-08-20', 'female', 45000, 'Employee', 'Indian', 'Bangalore, Karnataka', 'boosterhealth49@gmail.com', '9876543211', '2002-01-15', 'A-', 'Assistant', 'ICICI Bank', '0987654321', 'ICIC9876543', 'E0001'),
('E0003', 'password3', 'Amit', 'Singh', '1988-12-10', 'male', 40000, 'Employee', 'Indian', 'Mumbai, Maharashtra', 'amit@example.com', '9876543212', '2000-02-05', 'B+', 'Senior Engineer', 'HDFC Bank', '9876543210', 'HDFC9876543', 'E0001'),
('E0004', 'password4', 'Neha', 'Gupta', '1995-04-25', 'female', 50000, 'Manager', 'Indian', 'Delhi, Delhi', 'neha@example.com', '9876543213', '1999-03-20', 'AB-', 'HR Manager', 'Axis Bank', '6543210987', 'UTIB6543210', 'E0001'),
('E0005', 'password5', 'Rakesh', 'Kumar', '1993-09-08', 'male', 40000, 'Employee', 'Indian', 'Chennai, Tamil Nadu', 'rakeshkumar@example.com', '9876543214', '2000-04-10', 'A+', 'Software Developer', 'Punjab National Bank', '7890123456', 'PUNB7890123', 'E0001');

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
CREATE TABLE IF NOT EXISTS `holidays` (
  `holiday_id` int(11) NOT NULL,
  `holiday_title` varchar(255) NOT NULL,
  `holiday_desc` varchar(255) NOT NULL,
  `holiday_date` varchar(50) NOT NULL,
  `holiday_type` varchar(255) NOT NULL,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`holiday_id`, `holiday_title`, `holiday_desc`, `holiday_date`, `holiday_type`) VALUES
(1, 'Independence Day', 'Celebrating the independence of India', '2024-08-15', 'compulsory'),
(2, 'Diwali', 'Festival of lights', '2024-11-04', 'restricted'),
(3, 'Republic Day', 'Celebrating the formation of the Indian constitution', '2024-01-26', 'restricted'),
(4, 'Holi', 'Festival of colors', '2024-03-10', 'restricted'),
(5, 'Gandhi Jayanti', 'Celebrating the birth anniversary of Mahatma Gandhi', '2024-10-02', 'compulsory');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

DROP TABLE IF EXISTS `leaves`;
CREATE TABLE IF NOT EXISTS `leaves` (
  `leave_id` int(11) NOT NULL,
  `leave_subject` varchar(255) NOT NULL,
  `leave_from` date NOT NULL DEFAULT '2024-03-04',
  `leave_to` date NOT NULL DEFAULT '2024-03-04',
  `leave_message` longtext NOT NULL,
  `leave_status` varchar(255) NOT NULL DEFAULT 'pending',
  `apply_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emp_id` char(5) NOT NULL,
  PRIMARY KEY (`leave_id`),
  KEY `emp_id` (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`leave_id`, `leave_subject`, `leave_from`, `leave_to`, `leave_message`, `leave_status`, `apply_date`, `emp_id`) VALUES
(1, 'Family Vacation', '2024-03-04', '2024-03-05', 'I will be on vacation with my family during this period.', 'approve', '2024-06-15 10:00:00', 'E0001'),
(2, 'Sick Leave', '2024-02-04', '2024-02-05', 'I am unwell and unable to work during these days.', 'approve', '2024-09-03 09:30:00', 'E0002'),
(3, 'Personal Leave', '2024-03-15', '2024-03-15', 'I need to attend a family event on this day.', 'reject', '2024-11-10 14:00:00', 'E0001'),
(5, 'Training Program', '2024-03-04', '2024-03-04', 'I will be attending a training program organized by the company.', 'approve', '2024-09-25 13:30:00', 'E0005'),
(6, 'Fever', '2024-05-06', '2024-05-08', '7yh7nyh7yh7hjni', 'Pending', '2024-05-06 03:54:22', 'E0002');

-- --------------------------------------------------------

--
-- Table structure for table `payheads`
--

DROP TABLE IF EXISTS `payheads`;
CREATE TABLE IF NOT EXISTS `payheads` (
  `payhead_id` int(11) NOT NULL,
  `payhead_name` varchar(255) NOT NULL,
  `payhead_desc` varchar(255) NOT NULL,
  `payhead_type` varchar(255) NOT NULL,
  `payhead_percent` int(255) NOT NULL,
  PRIMARY KEY (`payhead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payheads`
--

INSERT INTO `payheads` (`payhead_id`, `payhead_name`, `payhead_desc`, `payhead_type`, `payhead_percent`) VALUES
(1, 'Provident Fund', 'Employee contribution to provident fund', 'deduction', 12),
(2, 'House Rent Allowance', 'Allowance for housing expenses', 'earning', 20),
(3, 'Professional Tax', 'Tax levied by the state government', 'deduction', 3),
(4, 'Dearness Allowance', 'cost-of-living adjustment.', 'earning', 12),
(5, 'Tax Deduction at Source', 'Tax Deducted at Source', 'deduction', 10);

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

DROP TABLE IF EXISTS `salaries`;
CREATE TABLE IF NOT EXISTS `salaries` (
  `salary_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` char(5) NOT NULL,
  `earning_total` float(11,2) NOT NULL,
  `deduction_total` float(11,2) NOT NULL,
  `net_salary` float(11,2) NOT NULL,
  `pay_month` varchar(255) NOT NULL,
  `total_earned` int(255) NOT NULL,
  PRIMARY KEY (`salary_id`,`pay_month`),
  KEY `emp_id` (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salaries`
--

INSERT INTO `salaries` (`salary_id`, `emp_id`, `earning_total`, `deduction_total`, `net_salary`, `pay_month`, `total_earned`) VALUES
(1, 'E0001', 1651.61, 670.97, 5161.29, '03', 6142),
(2, 'E0002', 464.52, 188.71, 1451.61, '03', 1727),
(3, 'E0003', 412.90, 167.74, 1290.32, '03', 1535),
(4, 'E0004', 516.13, 209.68, 1612.90, '03', 1919),
(5, 'E0005', 412.90, 167.74, 1290.32, '03', 1535);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `employees` (`emp_id`);

--
-- Constraints for table `leaves`
--
ALTER TABLE `leaves`
  ADD CONSTRAINT `leaves_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
