<?php 
include('connect.php');
session_start();
$emp_id =  $_SESSION['id'];
echo $emp_id; // Check if the form is submitted
   
$sql = "SELECT MAX(leave_id) AS max_leave_id FROM leaves";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$last_leave_id = $row['max_leave_id'] + 1;

$leave_subject = $_POST['leave_subject'];
$from = $_POST['from'];
$to = $_POST['to'];
$leave_message = $_POST['leave_message'];
$leave_status = 'Pending'; // Set leave status as pending by default
$apply_date = date('Y-m-d H:i:s'); // Current date and time



// Insert leave request into the database
$insert_query = "INSERT INTO `leaves`(`leave_id`, `leave_subject`, `leave_from`, `leave_to`, `leave_message`, `leave_status`, `apply_date`, `emp_id`) 
                 VALUES ('$last_leave_id','$leave_subject','$from','$to','$leave_message','$leave_status','$apply_date','$emp_id')";
    
$res = mysqli_query($conn, $insert_query);
if($res) {
    echo "Leave request submitted successfully.";
} else {
    echo "Error submitting leave request: " . mysqli_error($conn);
}
?>
