<?php include('start.php');
include('connect.php');?>
<html>
    <head>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      rel="stylesheet"
    />

 <link rel="stylesheet" href="holiday.css"/>

 <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>

 

</head>

    <body>
    <section class="home">
    <div class="container1" id="blur">
      <div class="text">
Holidays
      </div>
<div class="content">

     
<div class="container">
  <table class="rwd-table">
    <tbody>
      <tr>
        <th>Holiday Id</th>
        <th>Holiday Title</th>
        <th>Holiday DESCRIPTION</th>
        <th>Holiday Date</th>
        <th>Holiday TYPE</th>
      </tr>
      <?php
           
			$rows = mysqli_query($conn,"SELECT * FROM holidays");
			while ($row = mysqli_fetch_assoc($rows)) {
			?>
			<tr>
                <td> <?php echo $row["holiday_id"]; ?></td>
				<td> <?php echo  $row["holiday_title"]; ?> </td>
                <td> <?php echo  $row["holiday_date"]; ?> </td>
				<td> <?php echo $row["holiday_desc"]; ?> </td>
				<td> <?php echo $row["holiday_type"]; ?> </td>
			</tr>
      <?php }?>
    </tbody> 
</table>
</div>
</div>

</section>

</body>
</html>