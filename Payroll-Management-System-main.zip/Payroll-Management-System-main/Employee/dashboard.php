<?php
session_start(); 
include('start.php');
include('connect.php');

?>
<html>
<head>
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    rel="stylesheet"
  />   
  <link     rel="stylesheet" href="employee.css" /><script>
  <link rel="stylesheet" href="add.css"/>
  <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
 
</head>
<body>


  <section class="home">
    <div class="container1" id="blur">
      <div class="text">
        Employees
      </div>
      <div class="content">
       
  
        
        <div class="container">

        <h1>Welcome, <?php echo $_SESSION['emp_first_name'] . ' ' . $_SESSION['emp_last_name']; ?>!</h1>
        <p>Your ID: <?php echo $_SESSION['emp_id']; ?></p>
          
        </div>
      </div>
</body>
</html>
