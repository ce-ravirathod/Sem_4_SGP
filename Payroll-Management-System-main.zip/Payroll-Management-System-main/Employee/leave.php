
<?php include('start.php');
include('connect.php');
?>

<html>
<head>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet" />
<link rel="stylesheet" href="employee.css" />
<script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
<style>h3,
ul {
  margin: 0;
}
.wrapper{
  Width: 29%;
 
}
.contain{
  padding-top:20px;
  padding-bottom:0px;
}
h3 {
  margin-bottom: 1rem;
}

input:focus,
textarea:focus {
  outline: 3px solid gold;
}

input,
textarea,
button {
  width: 100%;
  border: 1px solid #000;
}

.wrapper {
  box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.2);
}
.wrapper > * {
  padding: 1em;
}
@media (min-width: 700px) {
  .wrapper {
    display: grid;
    grid-template-columns: 1fr 2fr;
  }
  .wrapper > * {
    padding: 2em 2em;
  }
}

ul {
  list-style: none;
  padding: 0;
}

.contacts {
  background: #4b5195;
  color: #fff;
}

.form {
  background: #fff;

  margin-bottom:2px;
}

form {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 20px;
}
form label {
  display: block;
}

.full-width {
  grid-column: 1 / 3;
}

button,
input,
textarea {
  padding: 1em;
}

button {
  background: lightgrey;
  width: 100%;
  border: 0;
}
button:hover, button:focus {
  background: gold;
  outline: 0;
}</style>
</head>
<body>
    <section class="home">
        <div class="container1" id="blur">
            <div class="text">
             Leaves 
               
            </div>
            <div class="content">
                <!-- Form for employees to apply for leave -->
            
                   <!--<form method="post">
                        <input type="hidden" name="emp_id" value="<?php echo $_SESSION['emp_id']; ?>">
                        <label for="leave_subject">Leave Subject:</label><br>
                        <input type="text" id="leave_subject" name="leave_subject" required><br>
                        <label for="leave_dates">Leave Dates:</label><br>
                        <input type="text" id="leave_dates" name="leave_dates" required><br>
                        <label for="leave_message">Leave Message:</label><br>
                        <textarea id="leave_message" name="leave_message" required></textarea><br>
                        <button type="submit" name="apply_leave">Apply</button>
                    </form>-->
                    <div class="contain">

                    <div class="wrapper" style="padding-bottom:0px;">
                      <div class="form">
                        <h3>Send us a message</h3>
                        <form action="lea.php" method='post'>

                          <p>
                            <label for="">Leave_subject</label>
                            <input type="text"  name="leave_subject" >
                          </p>
                          <p>
                            <label for="">Leave date from </label>
                            <input type="date"  name="from" >
                          </p>
                          <p>
                            <label for="">Leave date to</label>
                            <input type="date" name="to">
                          </p>
                          <p class="full-width">
                            <label for="">leave message</label>
                            <textarea name="leave_message" id="" cols="30" rows="7"></textarea>
                          </p>
                          <p class="full-width">
                          <button type="submit" name="apply_leave">Apply</button>
                          </p>
                        </form>
                      </div>
                      <div class="container" style="width:930px; margin-top:-7%;">
                              <table class="rwd-table">
                                <tbody>
                                  <tr>
                                   <th>#</th>
                                    <th>Subject</th>
                                    <th>Date From</th>
                                    <th>Date TO</th>
                                    <th>Message</th>
                                    <th>Status</th>
                                  </tr>
                                  <?php
                                      $i=0;
                                      $emp_id=$_SESSION['id'];
                                  $rows = mysqli_query($conn,"SELECT * FROM leaves where emp_id='$emp_id'");
                                  while ($row = mysqli_fetch_assoc($rows)) {
                                  ?>
                                  <tr>
                                    <td> <?php $i=$i+1; echo $i ?></td>
                                    <td> <?php echo  $row["leave_subject"]; ?> </td>
                                    <td> <?php echo  $row["leave_from"]; ?> </td>
                                    <td> <?php echo $row["leave_to"]; ?> </td>
                                    <td> <?php echo $row["leave_message"]; ?> </td>
                                    <td> <?php echo $row["leave_status"]; ?> </td>
                                  </tr>
                                  <?php }?>
                                </tbody> 
                            </table>
                            </div>
                    </div>
                    </div>
                                    </div>


                </div>
            </div><br><br>
            
        </div>
    </section>
</body>
</html>
