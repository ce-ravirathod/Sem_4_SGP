<?php 

include('start.php');
include('connect.php');

?>
<html>
<head>
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    rel="stylesheet"
  />   
  <link     rel="stylesheet" href="employee.css" /><script>

  
   
function openPopup() {
  document.getElementById("popupForm").style.display = "block";
}
function closePopup() {

  document.getElementById("popupForm").style.display = "none";
}
function openPopup1(empId) {
    localStorage.setItem("popupOpen", "true");
    window.location.href = "?empid=" + empId;
}

document.addEventListener("DOMContentLoaded", function() {
    var popupOpen = localStorage.getItem("popupOpen");
    var popupForm = document.getElementById("popupForm1");
    
    // Check if popupForm is initially opened
    if (popupOpen === "true") {
        popupForm.style.display = "block"; // Display the popup form initially
    } else {
        popupForm.style.display = "none"; // Hide the popup form initially
    }
    
    // Close the popup form if it's initially opened
    if (popupForm.style.display === "block") {
        localStorage.setItem("popupOpen", "false"); // Set popupOpen to "false" in localStorage
    }
});


    


function closePopup1() {
  document.getElementById("popupForm1").style.display = "none";
}

</script>
<?php if(isset($_GET['empid'])) {
   $empid = $_GET['empid'];
   echo $empid;
    $query="select * from employees where emp_id = '$empid'";
    $stat = mysqli_query($conn,$query);
    $data = mysqli_fetch_array($stat);
    if(isset($_POST["update"]))
    {
    $query="update `employees` set email='$_POST[email]',mobile='$_POST[mobile]',address='$_POST[address]',designation='$_POST[designation]',basicsalary='$_POST[basesalary]',emp_type='$_POST[emp_type]',bank_name='$_POST[bank]',account_no='$_POST[accno]',ifsc_code='$_POST[ifsc]' where emp_id='$empid'";
    $result1=mysqli_query($conn,$query);
    if(!$result1){
            echo '<script type="text/javascript"> '; 
            echo '  if (confirm("Update Unsuccessfull")) {';  
            echo '    document.location = "employee.php";';  
            echo '  }';  
            echo'</script>';
        }
        else{
            echo '<script type="text/javascript"> '; 
            echo '  if (confirm("Update successfull")) {';  
            echo '    document.location = "employee.php";';  
            echo '  }';  
            echo'</script>';
        }
}

    } else {
        echo "Employee not found";
    }
    ?>
    
  <link rel="stylesheet" href="add.css"/>
  <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
 
</head>
<body>


  <section class="home">
    <div class="container1" id="blur">
      <div class="text">
        Employees
      </div>
      <div class="content">
       
        
        
        <div class="container">
          <table class="rwd-table">
            <tbody>
              <tr>
                <th>Employee Code</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Joining Date</th>
                <th>Address</th>
                <th>Designation</th>
         
              </tr>
              
              <?php
              $id=$_SESSION['man_id'];
             
              $query = "SELECT * FROM employees";
              $query_run = mysqli_query($conn, $query);
              
              if (mysqli_num_rows($query_run) > 0) {
                  
                  while ($row = mysqli_fetch_assoc($query_run)) {
                    if($row['emp_id'] == $id) {
                        continue;
                    }
                  
                      ?>
                      <tr>

                        <td><?=  $row['emp_id'];?></td>
                        <td><a href="details.php?id1=<?php echo $row['emp_id'];?>"><?=  $row['first_name']; ?></a></td>
                        <td><?=  $row['last_name']; ?></td>
                        <td><?=  $row['mobile']; ?></td>
                        <td><?=  $row['email']; ?></td>
                        <td><?=  $row['joining_date']; ?></td>
                        <td><?=  $row['address']; ?></td>
                        <td><?=  $row['designation']; ?></td>
                       
                      </tr>
                      <?php
                  }
                }
            
              else {
                  echo "No data found";
              }
              
              // Close the connection
        
              ?>
            </tbody> 
          </table>
        </div>
      </div>


    
</body>
</html>
