<?php 
include('start.php');
include('connect.php');

// Check if the form is submitted
if(isset($_POST['submit']) && isset($_POST['leave_id']) && isset($_POST['status'])) {
    $leave_id = $_POST['leave_id'];
    $status = $_POST['status']; // This will contain the value of the selected radio button (Approved, Rejected, or Pending)
    
    // Update the leave status in the database
    $update_query = "UPDATE leaves SET leave_status = '$status' WHERE leave_id = '$leave_id'";

    // Execute the update query
    if(mysqli_query($conn, $update_query)) {
        echo "Leave status updated successfully.";
    } else {
        echo "Error updating leave status: " . mysqli_error($conn);
    }
}

?>
<html>
<head>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet" />
<link rel="stylesheet" href="holiday.css" />

<script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
</head>
<body>
    <section class="home">
        <div class="container1" id="blur">
            <div class="text">
                Leaves
            </div>
            <div class="content">
                <div class="container">
                    <b>List of Employee leaves :</b>
                    <table class="rwd-table">
                        <tbody>
                            <tr>
                                <th>Leave Id</th>
                                <th>Emp Id</th>
                                <th>Leave Subject</th>
                                <th>Leave From</th>
                                <th>Leave to</th>
                                <th>Leave Message</th>
                                <th>Leave Status</th>
                                <th>Action</th> <!-- For manager action -->
                            </tr>
                            <?php
                            $rows = mysqli_query($conn,"SELECT * FROM leaves where leave_status='pending'");
                            while ($row = mysqli_fetch_assoc($rows)) {
                            ?>
                            <tr>
                                <td><?php echo $row["leave_id"]; ?></td>
                                <td><?php echo $row["emp_id"]; ?></td>
                                <td><?php echo $row["leave_subject"]; ?></td>
                                <td><?php echo $row["leave_from"]; ?></td>
                                <td><?php echo $row["leave_to"]; ?></td>
                                <td><?php echo $row["leave_message"]; ?></td>
                                <td><?php echo $row["leave_status"]; ?></td>
                                <td>
                                    <!-- Form for manager action -->
                                    <form method="post">
                                        <input type="hidden" name="leave_id" value="<?php echo $row["leave_id"]; ?>">
                                        <select name="status">
                                            <option value="approve">Approve</option>
                                            <option value="reject" selected>Reject</option>
                                        </select>
                                        <br><br><button type="submit" name="submit">Update</button>
                                    </form>
                                </td>
                            </tr>


                            <?php }?>
                            
                            
                        </tbody> 
                    </table>
                    
                </div>
            </div><br><br>
            <div class="content">
            <center><b>After update Employee leaves :</b></center>
                <table class="rwd-table">
                    <!-- approve and reject -->
                    <tr>
                                <th>Leave Id</th>
                                <th>Emp Id</th>
                                <th>Leave Subject</th>
                                <th>Leave From</th>
                                <th>Leave to</th>
                                <th>Leave Message</th>
                                <!-- <th>Leave Status</th> -->
                                <th>Action</th>
                            </tr>
                            <?php
                            $rows = mysqli_query($conn,"SELECT * FROM leaves where leave_status='approve' or leave_status='reject'");
                            while ($row = mysqli_fetch_assoc($rows)) {
                            ?>
                            <tr>
                                <td><?php echo $row["leave_id"]; ?></td>
                                <td><?php echo $row["emp_id"]; ?></td>
                                <td><?php echo $row["leave_subject"]; ?></td>
                                <td><?php echo $row["leave_from"]; ?></td>
                                <td><?php echo $row["leave_to"]; ?></td>
                                <td><?php echo $row["leave_message"]; ?></td>
                                <td><?php echo $row["leave_status"]; ?></td>
                                <!-- <td>
                                    
                                    <form method="post">
                                        <input type="hidden" name="leave_id" value="<?php echo $row["leave_id"]; ?>">
                                        <select name="status">
                                            <option value="approve">Approve</option>
                                            <option value="reject" selected>Reject</option>
                                        </select>
                                        <br><br><button type="submit" name="submit">Update</button>
                                    </form>
                                </td> -->
                            </tr>
                            <?php }?>
                </table>
            </div>
        </div>
    </section>
</body>
</html>
