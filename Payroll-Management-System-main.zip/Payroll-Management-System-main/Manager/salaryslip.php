<?php 
session_start();
include('start.php');
include('connect.php');

?>
<html>
<head>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet" />   
  <link rel="stylesheet" href="employee.css" />
  <link rel="stylesheet" href="add.css"/>
  <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
</head>
<body>
<section class="home">
    <div class="text">
       salary
    </div>
    <div class="content">
        <div class="container">
            <table class="rwd-table">
                <tbody>
                    <tr>
                        <th>Salary ID</th>
                        <th>Month</th>
                        <th>Net-salary</th>
                        <th>Earnings</th>
                        <th>Deductions</th>
                        <th>Total Earned </th>
                        <th>Actions</th>
                    </tr>
                    <?php
                    $emp_id = $_SESSION['man_id'];
                    $rows = mysqli_query($conn,"SELECT * FROM salaries WHERE emp_id = '$emp_id'");
                    if(mysqli_num_rows($rows) > 0) {
                        while($row = mysqli_fetch_assoc($rows)) {
                    ?>
                    <tr>
                        <td><?php echo $row['salary_id']; ?></td>
                        <td><?php echo $row['pay_month']; ?></td>
                        <td><?php echo $row['net_salary']; ?></td>
                        <td><?php echo $row['earning_total']; ?></td>
                        <td><?php echo $row['deduction_total']; ?></td>
                        <td><?php echo $row['total_earned']; ?></td>
                        <td>
                            <a href="payslip.php?id1=<?php echo $row['emp_id'];?>">
                                <i class='bx bxs-receipt icon'></i>
                            </a>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else {
                        echo "<tr><td colspan='7'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
</body>
</html>
