<?php include('start.php'); include('connect.php');?>
<html>
    <head>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      rel="stylesheet"
    /> 
 <link rel="stylesheet" href="dashboard.css"/>
 <link rel="stylesheet" href="css.css"/>
 
</head>

    <body>
   
    <section class="home">
    <div class="text">
   Attendence
      </div>
<div class="content">
  
    <div class="container">
   
  <table class="rwd-table">
    <tbody>
      <tr>
        <th>Employee Id</th>
        <th> Date</th>
        <th>Punch-IN Time</th>
        <th>Punch-Out Time</th>
      </tr>
      <?php
			$rows = mysqli_query($conn,"SELECT * FROM attendence");
			while ($row = mysqli_fetch_assoc($rows)) {
			?>
			<tr>
				<td> <?php echo  $row["emp_id"]; ?> </td>
				<td> <?php echo $row["date"]; ?> </td>
				<td> <?php echo $row["punch_in"]; ?> </td>
				<td> <?php echo $row["punch_out"]; ?> </td>
			</tr>
      <?php }?>
      
  </table>



</div>
</div>
    </section>
</body>
</html>