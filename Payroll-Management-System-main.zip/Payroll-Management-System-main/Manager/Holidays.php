<?php include('start.php');
include('connect.php');?>
<html>
    <head>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      rel="stylesheet"
    />

 <link rel="stylesheet" href="holiday.css"/>

 <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>

 <script>
function openPopup() {
  document.getElementById("popupForm").style.display = "block";
}
function closePopup() {

  document.getElementById("popupForm").style.display = "none";
}
function openPopup1(hId) {
    localStorage.setItem("popupOpen", "true");
    window.location.href = "?hid=" + hId;
}

document.addEventListener("DOMContentLoaded", function() {
    var popupOpen = localStorage.getItem("popupOpen");
    var popupForm = document.getElementById("popupForm1");
    
    // Check if popupForm is initially opened
    if (popupOpen === "true") {
        popupForm.style.display = "block"; // Display the popup form initially
    } else {
        popupForm.style.display = "none"; // Hide the popup form initially
    }
    
    // Close the popup form if it's initially opened
    if (popupForm.style.display === "block") {
        localStorage.setItem("popupOpen", "false"); // Set popupOpen to "false" in localStorage
    }
});


    


function closePopup1() {
  document.getElementById("popupForm1").style.display = "none";
}

</script>

<?php 
if(isset($_GET['hid'])) {
   $hid = $_GET['hid'];
   echo $hid;
   $query="select * from holidays where holiday_id = '$hid'";
   $stat = mysqli_query($conn,$query);
   $data = mysqli_fetch_array($stat);
   if(isset($_POST["update"]))
   {
   $query="update `holidays` set holiday_title='$_POST[title]',holiday_desc='$_POST[desc]',holiday_date='$_POST[date]',holiday_type='$_POST[type]' where holiday_id='$hid'";
   $result1=mysqli_query($conn,$query);
   if(!$result1){
           echo '<script type="text/javascript"> '; 
           echo '  if (confirm("Update Unsuccessfull")) {';  
           //echo '    document.location = "Holiday.php";';  
           echo '  }';  
           echo'</script>';
       }
       else{
           echo '<script type="text/javascript"> '; 
           echo '  if (confirm("Update successfull")) {';  
          // echo '    document.location = "Holiday.php";';  
           echo '  }';  
           echo'</script>';
       }
}

   } else {
       echo "Payhead not found";
   }
    ?>

</head>

    <body>
    <section class="home">
    <div class="container1" id="blur">
      <div class="text">
Holidays
      </div>
<div class="content">

<div class="container">
  <table class="rwd-table">
    <tbody>
      <tr>
        <th>Holiday Id</th>
        <th>Holiday Title</th>
        <th>Holiday DESCRIPTION</th>
        <th>Holiday Date</th>
        <th>Holiday TYPE</th>
      </tr>
      <?php
           
			$rows = mysqli_query($conn,"SELECT * FROM holidays");
			while ($row = mysqli_fetch_assoc($rows)) {
			?>
			<tr>
                <td> <?php echo $row["holiday_id"]; ?></td>
				<td> <?php echo  $row["holiday_title"]; ?> </td>
                <td> <?php echo  $row["holiday_date"]; ?> </td>
				<td> <?php echo $row["holiday_desc"]; ?> </td>
				<td> <?php echo $row["holiday_type"]; ?> </td>

			</tr>
      <?php }?>
    </tbody> 
</table>
</div>
</div>

</section>


</body>
</html>