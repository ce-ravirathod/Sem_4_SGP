
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"/> 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" rel="stylesheet"/> 
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" rel="stylesheet"/> 

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>




<style>
    
    
    .left-table {
        float: left;
        margin-right: 20px; /* Add some spacing between tables */
    }
    
    /* CSS for right-aligned table */
    .right-table {
        float: right;
    }

    /* Style for table cells */
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
        padding: 80px;
    }
    </style>

</head>
<?php
 include('connect.php');
 $emp_code=$_GET['id1'];

 $query = "SELECT * FROM employees where emp_id='$emp_code'";
 $query_run = mysqli_query($conn, $query);
 
 if (mysqli_num_rows($query_run) > 0) {
     
     while ($row = mysqli_fetch_assoc($query_run)) {
        
        $first_name = $row['first_name'];
        $last_name = $row['last_name']; 
        $mobile = $row['mobile']; 
        $email = $row['email']; 
        $designation = $row['designation']; 
        $bank_name = $row['bank_name']; 
        $account_no = $row['account_no']; 
        $ifsc_code = $row['ifsc_code']; 
        $basicsalary = $row['basicsalary']; 
        $jdate=$row['joining_date'];


     }}

     $sql = "SELECT * FROM payheads";
    $result = $conn->query($sql);

// Initialize arrays to store earnings and deductions
$earnings = array();
$deductions = array();

if ($result->num_rows > 0) {
    // Loop through each payhead
    while ($row = $result->fetch_assoc()) {
        // Check payhead type and add to the respective array
        if ($row["payhead_type"] == "earning") {
            $earnings[] = $row;
        } elseif ($row["payhead_type"] == "deduction") {
            $deductions[] = $row;
        }
    }
}


    $rows1 = mysqli_query($conn,"SELECT * FROM salaries where emp_id='$emp_code'");
			foreach($rows1 as $row1) {
                $earning_total = $row1['earning_total'];
                $deduction_total = $row1['deduction_total']; 
                $total_earned = $row1['total_earned']; 
                $pay_month= $row1['pay_month'];
            }

            function numberToWords($number) {
                // Define arrays for mapping numbers to words
                $ones = array('', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine');
                $teens = array('ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen');
                $tens = array('', 'ten', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety');
                
                // Convert the number to words
                if ($number < 10) {
                    return $ones[$number];
                } elseif ($number < 20) {
                    return $teens[$number - 10];
                } elseif ($number < 100) {
                    return $tens[(int)($number / 10)] . (($number % 10 !== 0) ? '-' . $ones[$number % 10] : '');
                } elseif ($number < 1000) {
                    return $ones[(int)($number / 100)] . ' hundred' . (($number % 100 !== 0) ? ' and ' . numberToWords($number % 100) : '');
                } elseif ($number < 1000000) {
                    return numberToWords((int)($number / 1000)) . ' thousand' . (($number % 1000 !== 0) ? ' ' . numberToWords($number % 1000) : '');
                }
                // You can extend this logic for larger numbers if needed
            
                return 'Number out of range';
            }
    
?>

<body>
        <form method="post" action="salaryslip.php"><button class="btn btn-success" name="back"><i class="fa fa-backward"></i> back</button></form>
  
        
<div class="container mt-5 mb-5" >

    <div class="row">
        
        <div class="col-md-12">
          
                <table class="table table-striped" border="0">
               
        <tr >
            <td colspan="4" class="text-center">
                <b>PaySlip</b>
            </td>
        </tr>
        
        <tr>
            <td>Employee ID : <?php echo $emp_code?> <input type="hidden" name="ecode"></td>
            <td>Name:   <?php echo $first_name?> <?php echo $last_name?><input type="hidden"  value="" disabled></td>
        </tr>
       
        <tr>
            <td>Mobile NO :  <?php echo  $mobile?><input type="hidden" name="ename"></td>
            <td>Email :  <?php echo $email?><input type="hidden" name="paydate"></td>
        </tr>
      <tr>
            <td>Date Of Joining:   <?php echo $jdate?> <input type="hidden" name="ename"></td>
            <td>Designation: <?php echo $designation?><input type="hidden" name="paydate"></td>
        </tr>
       <tr>
            <td>Bank Name: <?php echo $bank_name?><input type="hidden" name="ename"></td>
            <td>Bank Account Number: <?php echo $account_no?><input type="hidden" name="paydate"></td>
        </tr>
      <tr>
         
            <td>IFSC Code : <?php echo $ifsc_code?><input type="hidden" name="ename"></td>
            <td>IFSC Code : <?php echo date("F", mktime(0, 0, 0, $pay_month, 1)) ?><input type="hidden" name="ename"></td>
            
        </tr>
        <tr>
            <td>
                <table class="table table-hover" border="2">
                    <tbody>
                    <tr>
                        <th>Earnings</th>
                        <th>Amount</th>
                    </tr>

                    <?php foreach ($earnings as $earning) {?>
                    <tr>
                        <td><?php echo $earning["payhead_name"]?></td>
                        <td><?php echo $earning["payhead_percent"].'%'?></td>
                    </tr>
                    <?php }?>
                    <tr>
                         <td><b>Total Earnings </b></td>
                        <td><?php echo  $earning_total?> <input type="hidden" name="tax"></td>
                    </tr>
                  
                    </tbody>
                    </td></table>
            <td>
                <table class="table table-hover" border="2">
                    <thead></thead>
                    <tbody>
                    <tr>
                        <th>Deductions</th>
                        <th>Amount</th>
                    </tr>
                   <?php foreach ($deductions as $deduction) {?>
                    <tr>
                        <td><?php echo $deduction["payhead_name"]?></td>
                        <td><?php echo $deduction["payhead_percent"].'%'?></td>
                    </tr>
                    <?php }?>
                       <tr>
                         <td><b>Total Deductions</b></td>
                        <td><?php echo $deduction_total?><input type="hidden" name="tax"></td>
                    </tr>
                    </tbody>
                </table>

            </div>
            <div class="row">
                <div class="col-md-4"> <br> <span class="fw-bold">Net Pay : <?php echo  $total_earned?></span> </div>
                <div class="border col-md-8">
                    <div class="d-flex flex-column"> <span>In Words</span> <span><?php echo  numberToWords($total_earned)?></span> </div>
                </div>
            </div>
            <div class="d-flex justify-content-end">
                <div class="d-flex flex-column mt-2"> <span class="fw-bolder"></span> <span class="mt-4">Authorised Signatory</span> </div>
            </div>
           

        </div>
    </div>
    
</div>
</div>




</body>
</html>
