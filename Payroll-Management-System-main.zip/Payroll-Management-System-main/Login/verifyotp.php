<?php
    session_start();
    $otpx=$_POST['otp'];
    $_SESSION['text']="not";
    
    if($otpx==$_SESSION['otp'])
    {
        header("location:newpassword.html");
        echo 'Sucessfull';
    }
    else
    {
        echo '<script type="text/javascript">';
        echo 'if (confirm("Otp varification failed  or invalid otp !")) {';
        echo 'document.location = "otp.html";';
        echo '}';
        echo '</script>';
    }
?>