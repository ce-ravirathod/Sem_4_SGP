<?php
session_start();
include('connect.php');
$user = $_POST['user'];
$_SESSION['user']=$user;
$query1 = "SELECT email FROM employees WHERE emp_id='$user'";
$cmd1 = mysqli_query($conn, $query1);

if ($cmd1) {
    if (mysqli_num_rows($cmd1) == 1) {
        $ans1 = mysqli_fetch_assoc($cmd1);
        $email1 = $ans1['email'];
        $user=$ans1['emp_id'];
        $_SESSION['email2']=$email1;

        header('location:send.php');
    } else {
        
            echo '<script type="text/javascript">';
            echo 'if (confirm("Employee Id does not exist or wrong id !")) {';
            echo 'document.location = "sendotp.html";';
            echo '}';
            echo '</script>';
        
    }
}
?>
