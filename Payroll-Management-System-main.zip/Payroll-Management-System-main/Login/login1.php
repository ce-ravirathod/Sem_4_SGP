<?php
session_start();
include('connect.php'); // Assuming connect.php contains database connection code

if(isset($_POST['Userid']) && isset($_POST['pass'])) {
    $user = $_POST['Userid'];
    $pass = $_POST['pass'];

    $query = "SELECT * FROM employees WHERE emp_id='$user' AND emp_password='$pass'";
    $result = mysqli_query($conn, $query);
    $_session['employeeid']=$user;
    if(mysqli_num_rows($result) == 1) {
        $employee = mysqli_fetch_assoc($result);
        $designation = $employee['emp_type'];
        $_SESSION['id']=$employee['emp_id'];
        
 switch ($designation) {
            case 'Admin':
                $_SESSION['adm_id']=$employee['emp_id'];
                header('location:/Project(payroll)/Admin/attendence.php');
                break;
            case 'Manager':
                $_SESSION['man_id']=$employee['emp_id'];
                header('location:/Project(payroll)/Manager/attendence.php');
                break;
            case 'Employee':
                $_SESSION['id']=$employee['emp_id'];
                header('location:/Project(payroll)/Employee/leave.php');
                break;
            default:
                echo 'Invalid designation';
        }
    }  else {
        echo '<script type="text/javascript">';
        echo 'if (confirm("Invalid Username and Password !")) {';
        echo 'document.location = "login.html";';
        echo '}';
        echo '</script>';
    }
} 
?>
