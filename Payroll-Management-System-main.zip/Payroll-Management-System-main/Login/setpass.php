<?php
session_start();
include('connect.php');
if(isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
}
// Get passwords from form
$pass1 = $_POST['pass1'];
$pass2 = $_POST['pass2'];
if ($pass1 == $pass2) {
    // Passwords match, proceed with update
    $query = "UPDATE employees SET emp_password = '$pass1' WHERE emp_id='$user'";
    $cmd = mysqli_query($conn, $query);
    
    if ($cmd) {
        echo '<script type="text/javascript">';
        echo '  if (confirm("Password updated succesfully")) {';
        echo '    document.location = "login.html";';
        echo '  }';
        echo '</script>';
    } 
} else {
    // Passwords don't match, display alert
    echo '<script type="text/javascript">';
    echo '  if (confirm("Both passwords must be the same")) {';
    echo '    document.location = "newpassword.html";';
    echo '  }';
    echo '</script>';
}
?>
