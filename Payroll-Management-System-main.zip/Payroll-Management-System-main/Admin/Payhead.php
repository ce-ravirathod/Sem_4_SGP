<?php include('start.php');
include('connect.php');?>
<html>
    <head>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      rel="stylesheet"
    />

 <link rel="stylesheet" href="payhead.css"/>

 <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>

 <script>
function openPopup() {
  document.getElementById("popupForm").style.display = "block";
}
function closePopup() {

  document.getElementById("popupForm").style.display = "none";
}
function openPopup1(pId) {
    localStorage.setItem("popupOpen", "true");
    window.location.href = "?pid=" + pId;
}

document.addEventListener("DOMContentLoaded", function() {
    var popupOpen = localStorage.getItem("popupOpen");
    var popupForm = document.getElementById("popupForm1");
    
    // Check if popupForm is initially opened
    if (popupOpen === "true") {
        popupForm.style.display = "block"; // Display the popup form initially
    } else {
        popupForm.style.display = "none"; // Hide the popup form initially
    }
    
    // Close the popup form if it's initially opened
    if (popupForm.style.display === "block") {
        localStorage.setItem("popupOpen", "false"); // Set popupOpen to "false" in localStorage
    }
});


    


function closePopup1() {
  document.getElementById("popupForm1").style.display = "none";
}

</script>

<?php 
if(isset($_GET['pid'])) {
   $pid = $_GET['pid'];
   echo $pid;
   $query="select * from payheads where payhead_id = '$pid'";
   $stat = mysqli_query($conn,$query);
   $data = mysqli_fetch_array($stat);
   

   if(isset($_POST["update"]))
   {
   $query="update `payheads` set payhead_name='$_POST[name]',payhead_desc='$_POST[desc]',payhead_type='$_POST[pay]', payhead_percent='$_POST[percent]'where payhead_id='$pid'";
   $result1=mysqli_query($conn,$query);
   if(!$result1){
           echo '<script type="text/javascript"> '; 
           echo '  if (confirm("Update Unsuccessfull")) {';  
           //echo '    document.location = "employee.php";';  
           echo '  }';  
           echo'</script>';
       }
    

   } }else {
       echo "Payhead not found";
   }
    ?>

</head>

    <body>
    <section class="home">
    <div class="container1" id="blur">
      <div class="text">
      Payhead
      </div>
<div class="content">

       
       <button class="btn" onclick="openPopup()"><i class="fa-solid fa-plus"></i>Add Payhead</button>
   

<div class="container">
  <table class="rwd-table">
    <tbody>
      <tr>
      <th>Payhead id</th>
        <th>Payhead NAME</th>
        <th>DESCRIPTION</th>
        <th>Payhead TYPE</th>
        <th>Payhead Percent</th>
        <th>Action</th>
      </tr>
      <?php
           
			$rows = mysqli_query($conn,"SELECT * FROM payheads");
			foreach($rows as $row) {
			?>
			<tr>
                <td> <?php echo $row["payhead_id"]; ?></td>
				<td> <?php echo  $row["payhead_name"]; ?> </td>
				<td> <?php echo $row["payhead_desc"]; ?> </td>
				<td> <?php echo $row["payhead_type"]; ?> </td>
				<td> <?php echo $row["payhead_percent"]; ?> </td>

                

                <td style="width: 200px; padding:0px;">
        <a  onclick="openPopup1('<?=$row['payhead_id'];?>')">
               <lord-icon src="https://cdn.lordicon.com/bxxnzvfm.json" trigger="hover"
                   colors="primary:#3a3347,secondary:#ffc738,tertiary:#f9c9c0,quaternary:#ebe6ef"
                   state="hover-1" style="width:40px;height:30px;display:inline-block;">
               </lord-icon>
        </a>
        
        <a href="deletepay.php?id=<?php echo $row['payhead_id'];?>">
        <lord-icon class="iconx" src="https://cdn.lordicon.com/qjwkduhc.json" trigger="hover"
            colors="primary:#646e78,secondary:#4bb3fd,tertiary:#ebe6ef" state="hover-empty"
            style="width:40px;height:30px;display:inline-block;">
        </lord-icon>
        </a>
                        </td>
			</tr>
      <?php }?>
    </tbody> 
</table>
</div>
</div>

</section>

<!---add -->

<div id="popupForm" class="popup">
    <div class="popup-content">
        <span class="close" onclick="closePopup()">&times;</span>
        <h2>Add Payhead :</h2>
        <div class="container-popup">
            <form action="addpayhead.php" method="Post" action="addpayhead.php">
                <div class="form first">
                    <div class="details personal">
                        <span class="title">Payhead Details</span>
                        <div class="fields">
                            <div class="input-field">
                                <label>Payhead Name</label>
                                <input type="text" name='name' required>
                            </div>
                            <div class="input-field">
                                <label>Payhead Description</label>
                                <input type="text" name="desc" required>
                            </div>
                            <div class="input-field">
                                <label>Payhead Percentage</label>
                                <input type="number" name="percent" required>
                            </div>
                            <div class="input-field">
                                <label>Payhead type</label>
                                <select id="pay" name="pay" style=' outline: none;font-size: 14px;
                                    font-weight: 400;color: #333;border-radius: 5px;border: 1px solid #aaa;padding: 0 15px;height: 42px;margin: 8px 0;'required>
                                    <option value="earnings">earnings</option>
                                    <option value="deductions">deductions</option>
                                </select>
                            </div>
                            <input type="Submit" name="update" value="Add Payhead" style='background: rgb(19, 160, 215); color: white; border: none; cursor: pointer; padding: 10px 30px; border-radius: 3px; box-shadow: 0px 4px 5px rgba(0, 0, 0, 0.2); transition: transform 0.3s ease-in-out; text-align: left; margin-left: 80%; margin-top: 3%; font-size: 14px;'>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>






<!--update-->
<div id="popupForm1" class="popup">
    <div class="popup-content">
        <span class="close" onclick="closePopup1()">&times;</span>
        <h2>Edit Payhead : <?php echo $data['payhead_id']; ?></h2>
        <div class="container-popup">
            <form method="Post">
                <div class="form first">
                    <div class="details personal">
                        <span class="title">Payhead Details</span>
                        <div class="fields">
                            <div class="input-field">
                                <label>Payhead Name</label>
                                <input type="text" name='name' value="<?php echo $data['payhead_name']; ?>" >
                            </div>
                            <div class="input-field">
                                <label>Payhead Description</label>
                                <input type="text" name="desc" value="<?php echo $data['payhead_desc']; ?>" >
                            </div>
                            <div class="input-field">
                                <label>Payhead type</label>
                                <select id="pay" name="pay" value='<?php $data['payhead_type'];?>' style=' outline: none;font-size: 14px;
                                    font-weight: 400;color: #333;border-radius: 5px;border: 1px solid #aaa;padding: 0 15px;height: 42px;margin: 8px 0;'>
                                    <option value="earnings" >earnings</option>
                                    <option value="deductions">deductions</option>
                                </select>
                                
                            </div>
                            <div class="input-field">
                                <label>Payhead Percentage</label>
                                <input type="number" name="percent" value="<?php echo $data['payhead_percent'];?>" recquired>
                            </div>
                            <input type="Submit" name="update" value="Update" style='background: rgb(19, 160, 215); color: white; border: none; cursor: pointer; padding: 10px 30px; border-radius: 3px; box-shadow: 0px 4px 5px rgba(0, 0, 0, 0.2); transition: transform 0.3s ease-in-out; text-align: left; margin-left: 80%; margin-top: 3%; font-size: 14px;'>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>