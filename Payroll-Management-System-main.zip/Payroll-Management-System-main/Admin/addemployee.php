<?php 
include('connect.php');

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $bdate = $_POST['bdate'];
    $gender = $_POST['gender'];
    $emp_type = $_POST['emptype'];
    $Nationality = $_POST['Nationality'];
    $address = $_POST['address'];
    $email = $_POST['email']; 
    $cno = $_POST['cno']; 
    $joining = $_POST['joining'];  
    $bgroup = $_POST['bgroup'];  
    $Designation = $_POST['Designation']; 
    $bank = $_POST['bank'];  
    $acc = $_POST['acc'];  
    $ifsc = $_POST['ifsc'];
    $managerid = $_POST['managerid'];
    $basesalary = $_POST['basesalary'];
    

    echo $fname  ;
    echo $lname  ;
    echo $bdate ;
    echo $gender  ;
    echo $emp_type  ;
    echo $Nationality  ;
    echo $address  ;
    echo $email  ; 
    echo $cno  ; 
    echo $joining ;  
    echo $bgroup  ;  
    echo $Designation ; 
    echo $bank  ;  
    echo $acc  ;  
    echo $ifsc ;
    echo $managerid ;

    // Default password
    $defaultPassword = "password@123";

$xyz = mysqli_query($conn,"SELECT * FROM `employees`");
while ($x = mysqli_fetch_array($xyz)){
    $id=$x['emp_id'];
}
$newid="E000".(ltrim($id,"E")+1);

    
      $query= $sql = "INSERT INTO employees VALUES ('$newid', '$defaultPassword', '$fname', '$lname', '$bdate', '$gender','$basesalary', '$emp_type', '$Nationality', '$address', '$email', '$cno', '$joining', '$bgroup', '$Designation', '$bank', '$acc', '$ifsc', '$managerid')";
        $result1=mysqli_query($conn,$query);
        if(!$result1){
                echo '<script type="text/javascript"> '; 
                echo '  if (confirm("Addition Unsuccessfull")) {';  
                 echo '    document.location = "employee.php";';  
                echo '  }';  
                echo'</script>';
            }
            else{
                echo '<script type="text/javascript"> '; 
                echo '  if (confirm("Addition successfull")) {';  
                echo '    document.location = "employee.php";';  
                echo '  }';  
                echo'</script>';
            }
    
   
?>
