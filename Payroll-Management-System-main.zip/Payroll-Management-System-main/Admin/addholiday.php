<?php 
include('connect.php');

    $title = $_POST['title'];
    
    $desc = $_POST['desc'];
    $date = $_POST['date'];
    $pay = $_POST['type'];


$xyz = mysqli_query($conn,"SELECT * FROM `holidays`");
while ($x = mysqli_fetch_array($xyz)){
    $id=$x['holiday_id'];
}
$newid=$id+1;

    
      $query="INSERT INTO holidays VALUES ('$newid','$title','$desc','$date','$pay')";
        $result1=mysqli_query($conn,$query);
        if(!$result1){
                echo '<script type="text/javascript"> '; 
                echo '  if (confirm("Addition Unsuccessfull")) {';  
               echo '    document.location = "Holidays.php";';  
                echo '  }';  
                echo'</script>';
            }
            else{
                echo '<script type="text/javascript"> '; 
                echo '  if (confirm("Addition successfull")) {';  
                echo '    document.location = "Holidays.php";';  
                echo '  }';  
                echo'</script>';
            }
    
   
?>
