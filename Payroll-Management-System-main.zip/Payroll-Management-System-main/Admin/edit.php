<?php 
include('start.php');
include('connect.php');



$user_id = $_SESSION['adm_id'];

// Fetch user data
$query = "SELECT * FROM employees WHERE emp_id = '$user_id'";
$result = mysqli_query($conn, $query);
$user_data = mysqli_fetch_assoc($result);

// Update profile if form is submitted
if(isset($_POST["update"])) {
    $contact_no = $_POST["contact_no"];
    $address = $_POST["address"];
    $new_password = $_POST["new_password"];
  

    // Check if new password matches confirm password
   
        // Hash the new password
       // $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Update user data
        $update_query = "UPDATE employees SET mobile='$contact_no', address='$address', emp_password='$new_password' WHERE emp_id='$user_id'";

        $update_result = mysqli_query($conn, $update_query);

        if($update_result) {
            echo '<script type="text/javascript">'; 
            echo '  if (confirm("Profile updated successfully")) {';  
           echo '    window.location.href = "edit.php";';  
            echo '  }';  
            echo '</script>';
        } else {
            echo '<script type="text/javascript">'; 
            echo '  if (confirm("Profile update failed")) {';  
            echo '    window.location.href = "edit.php";';  
            echo '  }';  
            echo '</script>';
        }
    } 

?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:600,700" rel="stylesheet">
    <style>
        /* Set background color and font for the entire page */
        .container {
            margin-left:40%;
            margin-top:100px;
            width: 450px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 5px 5px lightgrey;
            background-color:white;
        }

        /* Form title styling */
        h2 {
            background: #4B79A1; /* Form title background color */
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        /* Form input styling */
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            resize: vertical;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4B79A1; /* Update button background color */
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #2A4E7C; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Profile</h2>
        <form method="post"><br>    
            <div>
                <label>Contact Number:</label>
                <input type="text" name="contact_no" value="<?php echo $user_data['mobile']; ?>" required>
            </div>
            <div>
                <label>Address:</label>
                <input type="text" name="address" value="<?php echo $user_data['address']; ?>" required>
            </div>
            <div>
                <label>Password:</label>
                <input type="text" name="new_password" value="<?php echo $user_data['emp_password']; ?>">
            </div><br>
          
            <div>
                <input type="submit" name="update" value="Update">
            </div><br>
        </form>
    </div>
</body>
</html>
