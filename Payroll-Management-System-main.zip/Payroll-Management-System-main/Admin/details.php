<!DOCTYPE html>
<html lang="en">
<head><head>
    <meta charset="utf-8">
    <title>Employee Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body {
            margin-top: 20px;
            background-color: #f2f6fc;
            color: #69707a;
        }
        .img-account-profile {
            height: 10rem;
        }
        .rounded-circle {
            border-radius: 50% !important;
        }
        .card {
            box-shadow: 0 0.15rem 1.75rem 0 rgb(33 40 50 / 15%);
        }
        .card .card-header {
            font-weight: 500;
        }
        .card-header:first-child {
            border-radius: 0.35rem 0.35rem 0 0;
        }
        .card-header {
            padding: 1rem 1.35rem;
            margin-bottom: 0;
            background-color: rgba(33, 40, 50, 0.03);
            border-bottom: 1px solid rgba(33, 40, 50, 0.125);
        }
        .form-control, .dataTable-input {
            display: block;
            width: 100%;
            padding: 0.875rem 1.125rem;
            font-size: 0.875rem;
            font-weight: 400;
            line-height: 1;
            color: #69707a;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #c5ccd6;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border-radius: 0.35rem;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        .nav-borders .nav-link.active {
            color: #0061f2;
            border-bottom-color: #0061f2;
        }
        .nav-borders .nav-link {
            color: #69707a;
            border-bottom-width: 0.125rem;
            border-bottom-style: solid;
            border-bottom-color: transparent;
            padding-top: 0.5rem;
            padding-bottom: 0.5rem;
            padding-left: 0;
            padding-right: 0;
            margin-left: 1rem;
            margin-right: 1rem;
        }
    </style>
</head>
<body>
<?php
   include('connect.php');



    $emp_id =$_GET['id1'];
    $sql = "SELECT * FROM employees WHERE emp_id = '$emp_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc(); // Fetching the first row assuming emp_id is unique
?>
<div class="container">
    <div class="main-body">
        <div class="row">
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="Admin" class="rounded-circle p-1 bg-primary" width="110">
                            <div class="mt-3">
                                <h4><?php echo $row['first_name']; ?> <?php echo $row['last_name']; ?></h4>
                                <p class="text-secondary mb-1"><?php echo $row['designation']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-8">
                <div class="card mb-4">
                    <div class="card-header">Employee Details</div>
                    <div class="card-body">
                        <form>

<div class="row gx-3 mb-3">

<div class="col-md-6">
<label class="small mb-1" for="inputPhone">Employee ID</label>
<input class="form-control" id="inputPhone" type="tel" placeholder="Enter your phone number" value="<?php echo $row['emp_id']; ?>" readonly>
</div>

<div class="col-md-6">
<label class="small mb-1" for="inputBirthday">Manager ID</label>
<input class="form-control" id="inputBirthday" type="text" name="birthday" placeholder="Enter your birthday" value="<?php echo $row['manager_id']; ?>" readonly>
</div>
</div>



<div class="row gx-3 mb-3">

<div class="col-md-6">
<label class="small mb-1" for="inputFirstName">First name</label>
<input class="form-control" id="inputFirstName" type="text" placeholder="Enter your first name" value="<?php echo $row['first_name']; ?>">
</div>

<div class="col-md-6">
<label class="small mb-1" for="inputLastName">Last name</label>
<input class="form-control" id="inputLastName" type="text" placeholder="Enter your last name" value="<?php echo $row['last_name']; ?>">
</div>
</div>

<div class="row gx-3 mb-3">

<div class="col-md-6">
<label class="small mb-1" for="inputOrgName">Date Of Birth</label>
<input class="form-control" id="inputOrgName" type="text" placeholder="Date Of Birth "  value="<?php echo $row['dob']; ?>">
</div>

<div class="col-md-6">
<label class="small mb-1" for="inputLocation">Address</label>
<input class="form-control" id="inputLocation" type="text" placeholder="Enter your location" value="<?php echo $row['address']; ?>">
</div>
</div>

<div class="mb-3">
<label class="small mb-1" for="inputEmailAddress">Email address</label>
<input class="form-control" id="inputEmailAddress" type="email" placeholder="Enter your email address" value="<?php echo $row['email']; ?>">
</div>

<div class="row gx-3 mb-3">

<div class="col-md-6">
<label class="small mb-1" for="inputPhone">Phone number</label>
<input class="form-control" id="inputPhone" type="tel" placeholder="Enter your phone number" value="<?php echo $row['mobile']; ?>">
</div>

<div class="col-md-6">
<label class="small mb-1" for="inputBirthday">Nationality</label>
<input class="form-control" id="inputBirthday" type="text" name="birthday" placeholder="Enter your birthday" value="<?php echo $row['nationality']; ?>">
</div>
</div>

<div class="row gx-3 mb-3">

<div class="col-md-6">
<label class="small mb-1" for="inputPhone">Gender</label>
<input class="form-control" id="inputPhone" type="tel" placeholder="Enter your phone number" value="<?php echo $row['gender']; ?>">
</div>

<div class="col-md-6">
<label class="small mb-1" for="inputBirthday">Joining Date</label>
<input class="form-control" id="inputBirthday" type="text" name="birthday" placeholder="Enter your birthday" value="<?php echo $row['joining_date']; ?>">
</div>
</div>

<div class="row gx-3 mb-3">

<div class="col-md-6">
<label class="small mb-1" for="inputPhone">Blood Group</label>
<input class="form-control" id="inputPhone" type="tel" placeholder="Enter your phone number" value="<?php echo $row['blood_group']; ?>">
</div>

<div class="col-md-6">
<label class="small mb-1" for="inputBirthday">Designation</label>
<input class="form-control" id="inputBirthday" type="text" name="birthday" placeholder="Enter your birthday" value="<?php echo $row['designation']; ?>">
</div>
<div class="col-md-6">
<label class="small mb-1" for="inputBirthday">Salary</label>
<input class="form-control" id="inputBirthday" type="text" name="birthday" placeholder="Enter your birthday" value="<?php echo $row['basicsalary']; ?>">
</div>
</div>

</form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">Bank Details</div>
                    <div class="card-body">
                        <form>
<div class="row gx-3 mb-3">

<div class="col-md-6">
<label class="small mb-1" for="inputPhone">Bank Name</label>
<input class="form-control" id="inputPhone" type="tel" placeholder="Enter your phone number" value="<?php echo $row['bank_name']; ?>">
</div>

<div class="col-md-6">
<label class="small mb-1" for="inputBirthday">Account Number</label>
<input class="form-control" id="inputBirthday" type="text" name="birthday" placeholder="Enter your birthday" value="<?php echo $row['account_no']; ?>">
</div>
</div>

<div class="row gx-3 mb-3">

<div class="col-md-6">
<label class="small mb-1" for="inputPhone">IFSC Code</label>
<input class="form-control" id="inputPhone" type="tel" placeholder="Enter your phone number"  value="<?php echo $row['ifsc_code']; ?>">
</div>


</div>
</form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    } else {
        echo "<div class='card'>No data found</div>";
    }

    $conn->close();
?>
<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
    // Your custom JavaScript code
</script>
</body>
</html>