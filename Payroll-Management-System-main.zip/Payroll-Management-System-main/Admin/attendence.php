<?php include('start.php'); include('connect.php');?>
<html>
    <head>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      rel="stylesheet"
    /> 
 <link rel="stylesheet" href="dashboard.css"/>
 <link rel="stylesheet" href="css.css"/>
 
</head>

    <body>
   
    <section class="home">
        <div class="text">
            Import Attendence
        </div>
<div class="content">
<div class="xyz">
    <form class="click" action="import.php" method="post" enctype="multipart/form-data">
        <input type="file" name="excel" required value="">
       
        <button class="btn" type="submit" name="import">  <i class="fa-solid fa-plus"></i> Import</button>
    </form>
</div>
    
    <div class="container">
  <table class="rwd-table">
    <tbody>
      <tr>
        <th>Employee Code</th>
        <th> Date</th>
        <th>Punch-IN Time</th>
        <th>Punch-Out Time</th>
      </tr>
      <?php
			$rows = mysqli_query($conn,"SELECT * FROM attendence");
			foreach($rows as $row) {
			?>
			<tr>
				<td> <?php echo  $row["emp_id"]; ?> </td>
				<td> <?php echo $row["date"]; ?> </td>
				<td> <?php echo $row["punch_in"]; ?> </td>
				<td> <?php echo $row["punch_out"]; ?> </td>
			</tr>
      <?php }?>
      
  </table>



</div>
</div>
    </section>
</body>
</html>