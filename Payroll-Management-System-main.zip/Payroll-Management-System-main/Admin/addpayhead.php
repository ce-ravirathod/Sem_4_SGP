<?php 
include('connect.php');

    $name = $_POST['name'];
    echo $name;
    $desc = $_POST['desc'];
    echo $desc;
    $pay = $_POST['pay'];
    echo $pay;
    $per=$_POST['percent'];


$xyz = mysqli_query($conn,"SELECT * FROM `payheads`");
while ($x = mysqli_fetch_array($xyz)){
    $id=$x['payhead_id'];
}
$newid=$id+1;

    
      $query="INSERT INTO payheads VALUES ('$newid','$name','$desc','$pay','$per')";
        $result1=mysqli_query($conn,$query);
        if(!$result1){
                echo '<script type="text/javascript"> '; 
                echo '  if (confirm("Addition Unsuccessfull")) {';  
                echo '    document.location = "payhead.php";';  
                echo '  }';  
                echo'</script>';
            }
            else{
                echo '<script type="text/javascript"> '; 
                echo '  if (confirm("Addition successfull")) {';  
                echo '    document.location = "payhead.php";';  
                echo '  }';  
                echo'</script>';
            }
    
   
?>
