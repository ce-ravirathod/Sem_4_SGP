<?php 

include('start.php');
include('connect.php');

?>
<html>
<head>
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    rel="stylesheet"
  />   
  <link     rel="stylesheet" href="employee.css" /><script>

  
   
function openPopup() {
  document.getElementById("popupForm").style.display = "block";
}
function closePopup() {

  document.getElementById("popupForm").style.display = "none";
}
function openPopup1(empId) {
    localStorage.setItem("popupOpen", "true");
    window.location.href = "?empid=" + empId;
}

document.addEventListener("DOMContentLoaded", function() {
    var popupOpen = localStorage.getItem("popupOpen");
    var popupForm = document.getElementById("popupForm1");
    
    // Check if popupForm is initially opened
    if (popupOpen === "true") {
        popupForm.style.display = "block"; // Display the popup form initially
    } else {
        popupForm.style.display = "none"; // Hide the popup form initially
    }
    
    // Close the popup form if it's initially opened
    if (popupForm.style.display === "block") {
        localStorage.setItem("popupOpen", "false"); // Set popupOpen to "false" in localStorage
    }
});


    


function closePopup1() {
  document.getElementById("popupForm1").style.display = "none";
}

</script>
<?php if(isset($_GET['empid'])) {
   $empid = $_GET['empid'];
   echo $empid;
    $query="select * from employees where emp_id = '$empid'";
    $stat = mysqli_query($conn,$query);
    $data = mysqli_fetch_array($stat);
    if(isset($_POST["update"]))
    {
    $query="update `employees` set email='$_POST[email]',mobile='$_POST[mobile]',address='$_POST[address]',designation='$_POST[designation]',basicsalary='$_POST[basesalary]',emp_type='$_POST[emp_type]',bank_name='$_POST[bank]',account_no='$_POST[accno]',ifsc_code='$_POST[ifsc]' where emp_id='$empid'";
    $result1=mysqli_query($conn,$query);
    if(!$result1){
            echo '<script type="text/javascript"> '; 
            echo '  if (confirm("Update Unsuccessfull")) {';  
            //echo '    document.location = "employee.php";';  
            echo '  }';  
            echo'</script>';
        }
      
}

    } else {
        echo "Employee not found";
    }
    ?>
    
  <link rel="stylesheet" href="add.css"/>
  <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
 
</head>
<body>


  <section class="home">
    <div class="container1" id="blur">
      <div class="text">
        Employees
      </div>
      <div class="content">
       
        <button class="btn" onclick="openPopup()"><i class="fa-solid fa-plus"></i>Add Employee</button>
        
        <div class="container">
          <table class="rwd-table">
            <tbody>
              <tr>
                <th>Employee Code</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Joining Date</th>
                <th>Address</th>
                <th>Designation</th>
                <th>Action</th>
              </tr>
              
              <?php
                $id=$_SESSION['adm_id'];
              $query = "SELECT * FROM employees";
              $query_run = mysqli_query($conn, $query);
              
              if (mysqli_num_rows($query_run) > 0) {
                  
                  while ($row = mysqli_fetch_assoc($query_run)) {
                    if($row['emp_id'] == $id) {
                        continue;
                    }
                      ?>
                      <tr>

                        <td><?=  $row['emp_id'];?></td>
                        <td><a href="details.php?id1=<?php echo $row['emp_id'];?>"><?=  $row['first_name']; ?></a></td>
                        <td><?=  $row['last_name']; ?></td>
                        <td><?=  $row['mobile']; ?></td>
                        <td><?=  $row['email']; ?></td>
                        <td><?=  $row['joining_date']; ?></td>
                        <td><?=  $row['address']; ?></td>
                        <td><?=  $row['designation']; ?></td>
                        <td>
                                <?php $x=  $row['emp_id'];?>
                            <a  class="myLink"  onclick="openPopup1('<?=  $row['emp_id'];?>')"   >

                            
                                <lord-icon src="https://cdn.lordicon.com/bxxnzvfm.json" trigger="hover"
                                    colors="primary:#3a3347,secondary:#ffc738,tertiary:#f9c9c0,quaternary:#ebe6ef"
                                    state="hover-1" style="width:40px;height:30px;display:inline-block;">
                                </lord-icon>
                            </a>
                            
                            <a href="deleteemp.php?id=<?php echo $row['emp_id'];?> ">
                            <lord-icon class="iconx" src="https://cdn.lordicon.com/qjwkduhc.json" trigger="hover"
                                colors="primary:#646e78,secondary:#4bb3fd,tertiary:#ebe6ef" state="hover-empty"
                                style="width:40px;height:30px;display:inline-block;">
                            </lord-icon>
                            </a>
                        </td>
                      </tr>
                      <?php
                  }
              } else {
                  echo "No data found";
              }
              
              // Close the connection
        
              ?>
            </tbody> 
          </table>
        </div>
      </div>

<!-- Popup Form -->
<div id="popupForm" class="popup">
    <div class="popup-content">
      <span class="close" onclick="closePopup()">&times;</span>
      <h2>Add Employee</h2>
      <div class="container-popup">
      <form action="addemployee.php" method="post">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Personal Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>First Name</label>
                            <input type="text" name="fname" placeholder="Enter First Name" required >
                        </div>

                        <div class="input-field">
                            <label>Last Name</label>
                            <input type="text" name="lname" placeholder="Enter Last Name" required>
                        </div>

                        <div class="input-field">
                            <label>Email</label>
                            <input type="email" name="email" placeholder="Enter Email" id="email" required>
                        </div>

                        <div class="input-field">
                            <label>Mobile Number</label>
                            <input type="tel" name="cno" placeholder="Enter Mobile Number" required>
                        </div>
                        <div class="input-field">
                            <label>Gender</label>
                            <input type="text" name="gender" placeholder="Enter Gender" required>
                        </div>
                        <div class="input-field">
                            <label>Address</label>
                            <input type="text" name="address" placeholder="Enter Address" required>
                        </div>
                        <div class="input-field">
                            <label>BirthDate</label>
                            <input type="date" name="bdate" placeholder="Enter BirthDate"  required>
                        </div>
                        <div class="input-field" >
                            <label>Blood Group</label>
                            <input type="text" name="bgroup" placeholder="Enter Blood Group"  required>
                        </div>

                        <div class="input-field">
                            <label>Nationality</label>
                            <input type="text" name="Nationality" placeholder="Enter Nationality" required>
                        </div>
                       
                        

                 
                    </div>
                    
                </div>

                <div class="details company">
                    <span class="title">Company Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Joining date</label>
                            <input type="date" name="joining" placeholder="Enter Joining date" required>
                        </div>

                        <div class="input-field" >
                            <label>Designation</label>
                            <input type="text" name="Designation" placeholder="Enter Designation" required>
                        </div>
                        <div class="input-field">
                            <label>Employee type</label>
                            <input type="text" name="emptype" placeholder="Employee type" required>
                        </div>
                        <div class="input-field" style="margin-right:33%;">
                            <label>Manager id</label>
                            <input type="text" name="managerid" placeholder="Manager id" required>
                        </div>
                        <div class="input-field" >
                            <label>Base Salary</label>
                            <input type="text" name="basesalary" placeholder="Enter Basesalary" required>
                        </div>
                       

                        

                    </div>
                <div class="details Bank">
                <span class="title">Bank Details</span>
                    <div class="fields">
                    <div class="input-field">
                            <label>Bank Name</label>
                            <input type="text" name="bank" placeholder="Enter Bank Name" required >
                        </div>

                        <div class="input-field">
                            <label>Account NO</label>
                            <input type="text"  name="acc" placeholder="Enter Account NO" required >
                        </div>

                        <div class="input-field">
                            <label>IFSC Code</label>
                            <input type="text"  name="ifsc" placeholder="Enter IFSC Code"  required>
                           
                        </div>
                        <button class="submit">
                            <span class="submit" name="asubmit">Add employee</span>
                            <i class="uil uil-navigator"></i>
                        </button>
             
                    </div>
                </div>
            </div>

            
                   

                        
                </div>
            </div>
        </form>
    </div>
    </div>
  </div>
  </div>



<!--      edit form  -->


  <div id="popupForm1" class="popup">
    <div class="popup-content">
      <span class="close" onclick="closePopup1()">&times;</span>
      <h2>Edit Employee :<?php echo $data['emp_id'];?></h2>
      <div class="container-popup">
<form method="Post">
    <div class="form first">
                <div class="details personal">
                    <span class="title">Personal Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>First Name</label>
                            <input type="text" value="<?php echo $data['first_name'];?>" disabled>
                        </div>

                        <div class="input-field">
                            <label>Last Name</label>
                            <input type="text" value="<?php echo $data['last_name'];?>" disabled>
                        </div>

                        <div class="input-field">
                            <label>Email</label>
                            <input type="email"   name="email" value="<?php echo $data['email'];?>">
                        </div>

                        <div class="input-field">
                            <label>Mobile Number</label>
                            <input type="tel"  name="mobile" value="<?php echo $data['mobile'];?>">
                        </div>
                        <div class="input-field">
                            <label>Gender</label>
                            <input type="text" value="<?php echo $data['gender'];?>" disabled>
                        </div>
                        <div class="input-field">
                            <label>Address</label>
                            <input type="text"  name="address" value="<?php echo $data['address'];?>" >
                        </div>
                        <div class="input-field">
                            <label>BirthDate</label>
                            <input type="date"value="<?php echo $data['dob'];?>" disabled>
                        </div>
                        <div class="input-field" >
                            <label>Blood Group</label>
                            <input type="text" value="<?php echo $data['blood_group'];?>" disabled >
                        </div>

                        <div class="input-field">
                            <label>Nationality</label>
                            <input type="text" value="<?php echo $data['nationality'];?>" disabled>
                        </div>
                       
                        

                    </div>
                </div>

                <div class="details company">
                    <span class="title">Company Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Joining date</label>
                            <input type="date" value="<?php echo $data['joining_date'];?>" disabled>
                        </div>

                        <div class="input-field" >
                            <label>Designation</label>
                            <input type="text"  name="designation" value="<?php echo $data['designation'];?>" >
                        </div>
                        <div class="input-field">
                            <label>Employee type</label>
                            <input type="text"  name="emp_type" value="<?php echo $data['emp_type'];?>" >
                        </div>
                        <div class="input-field">
                            <label>Manager id</label>
                            <input type="text" value="<?php echo $data['manager_id'];?>" disabled>
                        </div>
                        <div class="input-field" style="margin-right:33%;">
                            <label>Base Salary</label>
                            <input type="text" name="basesalary"  value="<?php echo $data['basicsalary'];?>" >
                        </div>
                       

                        

                    </div>
                <div class="details Bank">
                <span class="title">Bank Details</span>
                    <div class="fields">
                    <div class="input-field">
                            <label>Bank Name</label>
                            <input type="text"  name="bank" value="<?php echo $data['bank_name'];?>"  >
                        </div>

                        <div class="input-field">
                            <label>Account NO</label>
                            <input type="text"  name="accno" value="<?php echo $data['account_no'];?>" >
                        </div>

                        <div class="input-field">
                            <label>IFSC Code</label>
                            <input type="text" name="ifsc" value="<?php echo $data['ifsc_code'];?>"  >
                        </div>
                        
                        <input type="Submit" name="update" value="Update"
                        style=' background: rgb(19, 160, 215); color: white;border: none;cursor: pointer;padding: 10px 30px;border-radius: 3px;box-shadow: 0px 4px 5px rgba(0, 0, 0, 0.2);
                        transition: transform 0.3s ease-in-out;text-align: left; margin-left: 80%; margin-top:3%;font-size:14px ;'>

                    </div>
                    <div id="output"></div>
                </div> 
</div>
  </section> 
      
            


   
    
</body>
</html>
