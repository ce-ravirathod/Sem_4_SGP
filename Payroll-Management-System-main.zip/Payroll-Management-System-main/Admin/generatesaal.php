<?php


include("connect.php");

$selectedMonthYear = $_POST["month"];

 
list($year, $month) = explode('-', $selectedMonthYear);

//echo "Selected Month: " . $month . "<br>";
//echo "Selected Year: " . $year;

/* count no of working days*/ 
$daysInMonth = date('t', strtotime($selectedMonthYear));
$weekdays = array();

for ($i = 1; $i <= $daysInMonth; $i++) {
  $day = date('N', strtotime("$selectedMonthYear-$i"));
  if ($day != 6 && $day != 7) {
    array_push($weekdays, $i);
  }
}

$remainingDays = count($weekdays);
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
//echo '<br>'.$daysInMonth;

//echo "<h3>Number of days in $selectedMonthYear without Saturdays and Sundays: $remainingDays</h3>";




//count no of holidays 
$start_date = date('Y-m-01', strtotime("$year-$month-01"));
$end_date = date('Y-m-t', strtotime("$year-$month-01"));
$sql = "SELECT COUNT(*) AS holiday_count FROM holidays WHERE holiday_date BETWEEN '$start_date' AND '$end_date'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
// Output data of each row
while($row = $result->fetch_assoc()) {
    //echo "Number of holidays in " . date('F Y', strtotime($start_date)) . ": " . $row["holiday_count"]."<br>";
    $Workingdays= $remainingDays- $row["holiday_count"];
  //  echo $Workingdays."<br>";
}
} else {
//echo "No holidays found in " . date('F Y', strtotime($start_date));
}




// Query to fetch all distinct emp_ids
$sql_emp_ids = "SELECT DISTINCT emp_id FROM attendence";
$result_emp_ids = $conn->query($sql_emp_ids);

if ($result_emp_ids->num_rows > 0) {
    // Loop through each employee
    while ($row_emp_id = $result_emp_ids->fetch_assoc()) {
        $emp_code = $row_emp_id["emp_id"];

        // Query to fetch attendance for the employee
        $sql_attendance = "SELECT date, punch_in, punch_out FROM attendence WHERE emp_id = '$emp_code' AND  MONTH(STR_TO_DATE(date, '%m-%d-%y')) = $month AND YEAR(STR_TO_DATE(date, '%m-%d-%y')) = $year";
        ;
        $result_attendance = $conn->query($sql_attendance);

        // Initialize arrays to store attendance information
        $attendance_days = array();
        $attendance_duration = 0;

        if ($result_attendance->num_rows > 0) {
            // Process each row of attendance data
            while ($row = $result_attendance->fetch_assoc()) {
                $date = $row['date'];
                $punch_in = strtotime($row['punch_in']);
                $punch_out = strtotime($row['punch_out']);

                // Calculate duration in seconds
                $duration = $punch_out - $punch_in;

                // Mark the day as attended
                $attendance_days[$date] = true;

                // Add duration to total duration
                $attendance_duration += $duration;
            }

            // Output attendance information
           /* $days_present = count($attendance_days);
            $hours1 = floor($attendance_duration / 3600); // Calculate hours from seconds
            $minutes = floor(($attendance_duration % 3600) / 60); // Calculate remaining minutes
            $seconds = $attendance_duration % 60; // Calculate remaining seconds
            echo "Employee $emp_code: $days_present days present for a total duration of $hours1 hours, $minutes minutes, and $seconds seconds.<br>";*/
            $days_present = count($attendance_days);
            $total_duration = $attendance_duration;
    
    
            $timestamp = strtotime( gmdate("H:i:s", $total_duration));
            $hours1 = date("H", $timestamp);
            if (date("i", $timestamp) > 40) {
                $hours1++;
            } elseif (date("i", $timestamp) == 30) {
                $hours1;
            }
        
          
         // echo "Employee $emp_code: $days_present days present for a total duration of " . gmdate("H:i:s", $total_duration) . "  Hours: " . $hours1 . " hours"."<br>";
    
        } else {
           // echo "No attendance records found for Employee $emp_code.<br>";
        }
                            
                            // Query to fetch rejected leaves for the specified employee and month
                    $sql = "SELECT leave_from, leave_to FROM leaves WHERE emp_id = '$emp_code' AND YEAR(leave_from) = $year AND MONTH(leave_from) = $month AND leave_status = 'approve'";
                    $result = $conn->query($sql);

                    // Initialize variable to store total rejected leave days
                    $totalRejectedLeaveDays = 0;

                    if ($result->num_rows > 0) {
                        // Loop through each rejected leave record
                        while ($row = $result->fetch_assoc()) {
                            $leaveFrom = new DateTime($row["leave_from"]);
                            $leaveTo = new DateTime($row["leave_to"]);

                            // Calculate the difference in days between leave_from and leave_to
                            $interval = $leaveFrom->diff($leaveTo);
                            $rejectedLeaveDays = $interval->days + 1; // Add 1 to include both leave_from and leave_to dates

                            // Add the rejected leave days to the total
                            $totalRejectedLeaveDays += $rejectedLeaveDays;
                        }
                    }
                   // echo "Total approved  leave days for employee $emp_code in $year-$month: $totalRejectedLeaveDays days".'<br>';

                            
                    $xyz="SELECT * FROM employees WHERE emp_id ='$emp_code'";
                    $result_xyz = $conn->query($xyz);
                    while ($row = $result_xyz->fetch_assoc()) {
                        $salary= $row['basicsalary'];

                    } 
                    $daysalary=$salary/$daysInMonth;
                
                    $totaldays=($days_present+$totalRejectedLeaveDays)*$daysalary;
                    //echo '<br>'.$totaldays;





                    $sql_salary = "SELECT basicsalary FROM employees WHERE emp_id = '$emp_code'";
                    $result_salary = $conn->query($sql_salary);

                    if ($result_salary->num_rows > 0) {
                        $row_salary = $result_salary->fetch_assoc();
                        $earned_salary = $row_salary['basicsalary'];

                        // Initialize variables to store total deductions and earnings
                        $total_deductions = 0;
                        $total_earnings = 0;

                        // Fetch payheads from the database
                        $sql_payheads = "SELECT * FROM payheads";
                        $result_payheads = $conn->query($sql_payheads);



                        if ($result_payheads->num_rows > 0) {
                            while ($row_payhead = $result_payheads->fetch_assoc()) 
                         
                            //$payhead_type = $row_payhead['payhead_type'];
                            while ($row_payhead = $result_payheads->fetch_assoc()) {
                                $payhead_name = $row_payhead["payhead_name"];
                                $payhead_desc = $row_payhead["payhead_desc"];
                                $payhead_type = $row_payhead["payhead_type"];
                                $payhead_percent = $row_payhead["payhead_percent"];
                    
                                // Calculate amount based on percentage of earned salary
                                $amount = ($totaldays * $payhead_percent) / 100;
                    
                                // Determine if it's a deduction or earning and update respective total
                                if ($payhead_type === 'deduction') {
                                    $total_deductions += $amount;
                                } else {
                                    $total_earnings += $amount;
                                }
                            }
                    

                            echo "Total Deductions: $total_deductions<br>";
                            echo "Total Earnings: $total_earnings<br>";

                            $total_earned=($totaldays+$total_earnings)-$total_deductions;
                            echo $total_earned;
                    
                            $insert_sal="insert into salaries values(null, '$emp_code','$total_earnings','$total_deductions','$totaldays','$month','$total_earned') ";
                           $x=mysqli_query($conn,$insert_sal);
                            if($x)
                            {
                                echo '<script type="text/javascript"> '; 
                                echo '  if (confirm("Generated successfull")) {';  
                                echo '    document.location = "generate salary.php";';  
                                echo '  }';  
                                echo'</script>';
                              

                            }
                            else 
                            {
                                echo '<script type="text/javascript"> '; 
                                echo '  if (confirm("Generated unsuccessfull")) {';  
                                echo '    document.location = "generate salary.php";';  
                                echo '  }';  
                                echo'</script>';
                            }
                    header("location:generate salary.php");
                    }
                }           
       
                    
                    }
} else {
    echo "No employees found.<br>";
    header("location:generate salary.php");
}




?>

