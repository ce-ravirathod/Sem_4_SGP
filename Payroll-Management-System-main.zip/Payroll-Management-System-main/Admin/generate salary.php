<?php include('start.php'); include('connect.php');?>
<html>
    <head>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      rel="stylesheet"
    /> 
 <link rel="stylesheet" href="dashboard.css"/>
 <link rel="stylesheet" href="css.css"/>
 
</head>

    <body>
   
    <section class="home">
        <div class="text">
           Generate salary
        </div>
<div class="content">
<div class="xyz">

  <form action="generatesaal.php" method="post" style="display:inline-block;" >
    <label for="month">Select Month:</label>
    <input type="month" id="month" name="month" style="display:inline-block;">
    <button type="submit" name="submit" style=" background: rgb(19, 160, 215);
  color: white;
  border: none;
  cursor: pointer;
  padding: 10px 30px;
  border-radius: 3px;
  box-shadow: 0px 4px 5px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s ease-in-out;
  text-align: left;
  margin-left: 80%;

  font-size:14px ;">Submit</button>
  </form>

</div>
    
    <div class="container">
  <table class="rwd-table">
    <tbody>
      <tr>
        <th>Salary ID</th>
        <th>Employee Id</th>
        <th>Month</th>
        <th>Net-salary</th>
        <th>Earnings</th>
        <th>Deductions</th>
        <th>Total Earned </th>
        <th>Actions</th>
      </tr>
      <?php
			$rows = mysqli_query($conn,"SELECT * FROM salaries");
			foreach($rows as $row) {
			?>
			<tr>
				<td> <?php echo $row['salary_id'] ?> </td>
				<td> <?php echo $row['emp_id']  ?> </td>
				<td> <?php  echo $row['pay_month']?> </td>
				<td> <?php echo $row['net_salary']?> </td>
                <td> <?php echo $row['earning_total']?> </td>
                <td> <?php  echo $row['deduction_total']?> </td>
                <td> <?php  echo $row['total_earned']?> </td>

              <td><a href="payslip.php?id1=<?php echo $row['emp_id'];?>">
                        <i class='bx bxs-receipt icon'></i>
                          
                        </a> <td>
                
			</tr>
      <?php }?>
      
  </table>



</div>
</div>
    </section>
</body>
</html>