<?php
require 'connect.php'; // Include your database connection script

// Include the required PHPExcel files
require 'excelReader/excel_reader2.php';
require 'excelReader/SpreadsheetReader.php';

if(isset($_POST["import"])){
    $fileName = $_FILES["excel"]["name"];
    $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);

    // Check if the file is an Excel file
    if(strtolower($fileExtension) == 'xls' || strtolower($fileExtension) == 'xlsx'){
        $newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;
        $targetDirectory = "uploads/" . $newFileName;
        
        // Move the uploaded file to the uploads directory
        if(move_uploaded_file($_FILES['excel']['tmp_name'], $targetDirectory)){
            $reader = new SpreadsheetReader($targetDirectory);

            // Loop through each row of the Excel file
            foreach($reader as $key => $row){
                if($key == 0){ // Skip header row
                    continue;
                }

                // Retrieve data from the current row
                $emp_code = $row[0];
                $date = $row[1];
                $punchin =date('H:i:s', strtotime($row[2]));
                $punchout = date('H:i:s', strtotime($row[3]));

                // Insert data into the database
                $query = "INSERT INTO attendence VALUES ('$emp_code', '$date', '$punchin', '$punchout')";
                $result = mysqli_query($conn, $query);

                // Check if the query was successful
                if($result){
                    echo "Data inserted successfully.<br>";
                } else {
                    echo "Error inserting data: " . mysqli_error($conn) . "<br>";
                }
            }

            echo "<script>alert('Successfully imported data.');document.location.href = 'attendence.php';</script>";
        } else {
            echo "<script>alert('Failed to move uploaded file.'); document.location.href = 'attendence.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid file format. Please upload an Excel file.');document.location.href = 'attendence.php';</script>";
    }
}
?>
