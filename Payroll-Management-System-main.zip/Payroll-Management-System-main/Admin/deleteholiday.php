<?php 
include('connect.php');
$id=$_GET['id'];

$query="DELETE FROM holidays WHERE holiday_id = '$id'";
$stat = mysqli_query($conn,$query);
if(!$stat){
    echo '<script type="text/javascript"> '; 
    echo '  if (confirm("Deleted Unsuccessfull")) {';  
    echo '    document.location = "Holidays".php";';  
    echo '  }';  
    echo'</script>';
    header("Refresh:0");
}
else{
    echo '<script type="text/javascript"> '; 
    echo '  if (confirm("Deleted successfull")) {';  
    echo '    document.location = "Holidays.php";';  
    echo '  }';  
    echo'</script>';
    header("Refresh:0");
}

?>