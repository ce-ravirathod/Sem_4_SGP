<?php
session_start();
session_destroy();
header("Location: /Project(payroll)/Login/login.html");
?>